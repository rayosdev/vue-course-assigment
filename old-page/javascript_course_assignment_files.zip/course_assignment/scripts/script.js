// refer to question 1 before development starts for scope document
// connect to this api https://api.magicthegathering.io/v1/cards